<?php

if(isset($_GET['_id']) && $_GET['_id']!=""){
	$id=htmlspecialchars($_GET['_id']);
	include("db.php");
	$query="select verificationhash from user where verificationhash='$id'";
	$result = mysqli_query($conn, $query);
	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			if($row['verificationhash'] == $id){
				$sql = "UPDATE user SET status='active' WHERE verificationhash='$id'";
                if (mysqli_query($conn, $sql)) {
                    header("location:dashboard.php");
                }
                else{
                    echo "error";
                }
			}
			else{
				echo "error";
			}
		}
	}
}
else{
    header("location:http://localhost/Charusat-Tool/views/login.php");
}

?>