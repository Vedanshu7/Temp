<?php
 session_start();
 
 include("./db.php");
 $name=trim($_POST['name']);
 $email=trim($_POST['email']);
 $password=md5(trim($_POST['pass']));
 $status=trim("inactive");
 $flag=true;
 $query="select email from user where email='$email'";
 $result = mysqli_query($conn, $query);
 if (mysqli_num_rows($result) > 0) {
     while($row = mysqli_fetch_assoc($result)) {
         if($row['email']==$email){
             $flag=false;
             echo "<script>alert('Email already exists')</script>";
             header("location:SignUp.php");
            }
        }
    }
    if($flag){
        $value=$name."  ".$email.strval(rand());
        $value=md5($value);
        $sql ="INSERT INTO user(id,user_name,email,password,status,verificationhash) values(NULL,'".$name."','".$email."','".$password."','".$status."','".$value."')";
        if(mysqli_query($conn, $sql)){
            $verificationCode = $value;
            $verificationLink = "http://localhost/Charusat-Tool/views/verify.php/" . $verificationCode;
            $htmlStr = "";
            $htmlStr .= "Hi " . $email . ",<br /><br />";
            $htmlStr .= "Please click the button below to verify your email and have access to the tool.<br /><br /><br />";
            $htmlStr .= "<a href='{$verificationLink}' target='_blank' style='padding:1em; font-weight:bold; background-color:blue; color:#fff;'>VERIFY EMAIL</a><br /><br /><br />";
            $htmlStr .= "Kind regards,<br />";
            $htmlStr .= "<a href='http://localhost/Charusat-Tool/views/login.php' target='_blank'>Tool</a><br />";
            $name = "Verification Link";
            $email_sender = "syserrorlogin@gmail.com";
            $subject = "Verification Link";
            $recipient_email = $email;
            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
            $headers .= "From: {$name} <{$email_sender}> \n";
            $body = $htmlStr;
            if( mail($recipient_email, $subject, $body, $headers) ){
                header("location:login.php");
            } 
            else{
               // echo "not";
            }
        }
        else{
            //echo "error";
        }
    }

?>