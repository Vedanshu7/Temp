<?php
//include('config.php');
include('getcode.php');
include('db.php');
?>
<html>
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>PHP Login using Google Account</title>
  <meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
  
 </head>
 <body>
  <div class="container">
   <br />
   <h2 align="center">PHP Login using Google Account</h2>
   <br />
   <div class="panel panel-default">
   <?php
   if($_SESSION['btn'] == '')
   {
    $access_token=$_SESSION['access_token'];
    $gname=$_SESSION['user_first_name'];
    $email=$_SESSION['user_email_address'];
    $fname=$_SESSION['user_last_name'];
    $flag=true;
    $query="select access_token,email from googlelogin where email='$email'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            if($row['email']==$email){
                $flag=false;
                $sql = "UPDATE googlelogin SET access_token='$access_token' WHERE email='$email'";
                if (mysqli_query($conn, $sql)) {
                    header("location:dashboard.php");
                }
                else{
                    echo "error";
                }
                
            }
        }
    }
    if($flag){
        $sql ="INSERT INTO googlelogin(access_token,given_name,family_name,email) values('".$access_token."','".$gname."','".$fname."','".$email."')";
        if(mysqli_query($conn, $sql)){
            header("location:dashboard.php");
            
        }
        else{
            echo("Error");
        }
    }
}
else
   {
    header('Location:login.php');
   }
   ?>
   </div>
  </div>
 </body>
</html>