from .colors 	import *
from .functions import *
from .banner 	import banner as Banner
from .footer 	import footer as Footer