from .colors import *

footer = """
  {white}[{green}${white}] {cyan}Thanks For Using {white}:D
\t{blue}~ {red}An0n 3xPloiTeR {white}:)
""".format(
        white = w,
        green = g,
        cyan = c,
        blue = b,
        red = r
    )
