"""
_______________.___.
\______   \__  |   |
 |    |  _//   |   |
 |    |   \\____   |
 |______  // ______|
        \/ \/       
   _____         _______           ________        __________.__         ._____________   __________ 
  /  _  \   ____ \   _  \   ____   \_____  \___  __\______   |  |   ____ |__\__    _______\______   \
 /  /_\  \ /    \/  /_\  \ /    \    _(__  <\  \/  /|     ___|  |  /  _ \|  | |    |_/ __ \|       _/
/    |    |   |  \  \_/   |   |  \  /       \>    < |    |   |  |_(  <_> |  | |    |\  ___/|    |   \
\____|__  |___|  /\_____  |___|  / /______  /__/\_ \|____|   |____/\____/|__| |____| \___  |____|_  /
        \/     \/       \/     \/         \/      \/                                     \/       \/ 

                                ~ Changing Coder Name Wont Make You One :)
                                             ~ An0n 3xPloiTeR :)
"""

#####################################################################################################
        ################################   Importing Packages   ################################ 
#####################################################################################################

from insides import *

from modules import findShells

import sys

#####################################################################################################
        ################################   Variables!   ################################ 
#####################################################################################################

line        = "-" * 69
user_agent  = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.17 Safari/537.36"
val_Select  = f"\t{r}[$] Please Use The Index Value From The List\n\t\t[+] Not By Your Own :/\n\t\t\t ~ An0n 3xPloiTeR  \n"
str_Index   = f"\n\t{r}[=] Please Input a Integer (i.e, 1, 2, 3) :\\\n\t\t{c}~ An0n 3xPloiTeR :)"
_headers    = {
    'User-Agent': user_agent,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Encoding': 'gzip,deflate,sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'Connection': 'keep-alive'
}

#####################################################################################################
        ################################   Built-IN Functions   ################################ 
#####################################################################################################


def heading(heading, website, color, afterWebHead):
    space = " " * 15
    var = str(space + heading + " '" + website + "'" + str(afterWebHead) + " ..." + space)
    length = len(var) + 1; print() # \n
    print(f"{w}" + "-" * length + "-")
    print(f"{color}" + var)
    print(f"{w}" + "-" * length + "-"); print() # \n

#####################################################################################################
        ################################   Script's Banner   ################################ 
#####################################################################################################

#print(Banner)

#####################################################################################################

website = sys.argv[1]

#print(f"\n{g}[@] What You Wanna Do With The Given Website ? \n\n1). Cloudflare Check. \n2). Website Crawler.\n3). Reverse IP.\n4). Information Gathering.\n5). Nameservers.\n6). WebSite Speed.\n7). Subdomains Scanner.\n8). Shell Finder.\n9). Admin Panel Finder.\n10). Grab Banner.\n11). All Things.\n")



#####################################################################################################
        ################################   Real Shit   ################################ 
#####################################################################################################

try:

        #heading(heading="Shells Of", website=website, afterWebHead="", color=c)
        findShells(website)        

        


except KeyboardInterrupt:
    write(var="~", color=w, data="Err0r: User Interrupted!")
    
# except Exception, e:
#     write(var="#", color=r, data="Err0r: Kindly Report the err0r below to An0n3xPloiTeR :) (If Your Internet's Working ;)\n\"\"\"\n" + str(e) + "\n\"\"\"")

#print(Footer)

# See Ya!
# An0n 3xPloiTeR :)
