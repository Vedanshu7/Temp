<?php
ini_set('display_errors',0);
include("db.php");
session_start();
if(!isset($_SESSION['user_email_address'])){
   session_destroy();
   header("location:login.php");
}
function get_domain($url)
{
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : $pieces['path'];
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}

function replace($string){
	$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\[\]\.\(\)%&-]/s', '', $string);
    return $string;
}


function replace1($string){
	$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\[\]\.\(\)%&]/s', '', $string);
    return $string;
}

function rawdata($result)
{
	$out = array();
	$other=array();
	$ds=0;
	$ns=0;
	$ad=-1;
	$n=0;
	foreach ($result as $line){
		if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }

		if(substr_count($line,":") > 1){
		  $loc=strpos($line,":");
          $ps = str_split($line,$loc+1);
          
          if(sizeof($ps)>2){
          	for($i=2;$i<sizeof($ps);$i++){
          		$ps[1].=$ps[$i];
          	}
          }
          $temp=explode(":", $ps[0]);
          if($temp[0]=="Domain Status"){
          	$temp[0]=$temp[0].$ds;
          	$ds+=1;
          }
          if($temp[0]=="Name Server"){
          	$temp[0]=$temp[0].$ns;
          	$ns+=1;
          }
          if($temp[0]=="Address"){
          	 if($ad==-1){
          	 	$ad+=1;
          	 }
          	 else{
          	$temp[0]=$temp[0].$ad;
          	$ad+=1;
          }
          }
          if($temp[0]=="Name"){
          	$temp[0]=$temp[0].$n;
          	$n+=1;
          }
          $out[trim($temp[0])] =trim(replace($ps[1]));
		  
		  
		}
		else if(substr_count($line,":") < 1){
			$other.=$line.",";
		}
		else{
		$ps = explode(':',$line);
		//echo $ps;
		if($ps[0]=="Domain Status"){
          	$ps[0]=$ps[0].$ds;
          	$ds+=1;
          }
          if($ps[0]=="Name Server"){
          	$ps[0]=$ps[0].$ns;
          	$ns+=1;
          }
          if($ps[0]=="Address"){
          	if($ad==-1){
          	 	$ad+=1;
          	 }
          	 else{
          	$ps[0]=$ps[0].$ad;
          	$ad+=1;
          }
          }
          if($ps[0]=="Name"){
          	$ps[0]=$ps[0].$n;
          	$n+=1;
          }
		$out[trim($ps[0])] =trim(replace($ps[1]));	
		}
		}		
		return $out;
}
function srawdata($result)
{
	
	$other="";
	$out=array();
	foreach ($result as $line){
		if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }
		if(substr_count($line,":") < 1){
			$other.=$line.",";
		}
		
		}
		preg_match_all('#[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $other, $match);
		for($i=0;$i<sizeof($match[0]);$i++){
			if(get_domain($match[0][$i])!=false){
				array_push($out,$match[0][$i]);
			}
		}
		return $out;
}
function removenikto($result){
	$out = array();
	
	foreach ($result as $line){
		if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }

		if(substr_count($line,":") > 1){
		  $loc=strpos($line,":");
          $ps = str_split($line,$loc+1);
          
          if(sizeof($ps)>2){
          	for($i=2;$i<sizeof($ps);$i++){
          		$ps[1].=$ps[$i];
          	}
          }
          $temp=explode(":", $ps[0]);
          
          $out[trim(replace1($temp[0]))] =trim(replace1($ps[1]));
		  
		  
		}
		else if(substr_count($line,":") < 1){
			if(replace1($line)!="" && replace1($line)!=" " && replace1($line)!="Nikto v2.1.6" && replace1($line)!=" Nikto v2.1.6"){
				$out["Other Info"].=replace1($line).",";
			}
			
		}
		else{
		$ps = explode(':',$line);
		//echo $ps;
		
		$out[trim(replace1($ps[0]))] =trim(replace1($ps[1]));	
		}
		}
		
		return $out;
}


function replace2($string){
	$string=preg_replace('/[^a-zA-Z0-9_\/\/\:%\[\]\.\(\)%&\|]/s', '', $string);
    return $string;
}



function removeasci($test){
	$test=preg_replace('#\\x1b[[][^A-Za-z]*[A-Za-z]#', '', $test);
	return $test;
}
function startsWith ($string, $startString) 
{ 
    $len = strlen($startString); 
    return (substr($string, 0, $len) === $startString); 
} 
function put_file($target,$mode,$tool,$filename,$data)
{
	
	while (true) {
	$mainpath = getcwd()."/Output";
	if(is_dir($mainpath)) {
		$mainpath.="/".$target;
		if(is_dir($mainpath)){
			$mainpath.="/".$mode;
			if(is_dir($mainpath)){
				$mainpath.="/".$tool;
				if(is_dir($mainpath)){
					$mainpath.="/".$filename;
					$myfile = fopen($mainpath, "w") or die("Unable to open file!");
					fwrite($myfile, $data);
					fclose($myfile);
					return $mainpath;
					break;
				}
				else{
					mkdir($mainpath);
				}
			}
			else{
				mkdir($mainpath);
			}
		}
		else{
			mkdir($mainpath);
		}
	} else {
		mkdir($mainpath);
	}
}
}
function remove_http($url) {
   $disallowed = array('http://', 'https://');
   foreach($disallowed as $d) {
      if(strpos($url, $d) === 0) {
         return str_replace($d, '', $url);
      }
   }
   return $url;
}

$target=remove_http($_GET['target']);
$mode="Easy";
$userid=$_GET['email'];
$str = exec("ping -c 1 '$target'");
if ($result == 0){
  //echo "ping succeeded";
}else{
  $mode="";
}


switch ($mode) {
	case 'Easy':
	
	//1st tool
	$whoisoutput = shell_exec("whois -H '$target'");
		$whoisresult = explode("\n",$whoisoutput);

		$col=array("Domain Name", "Registry Domain ID", "Registrar WHOIS Server", "Registrar URL", "Updated Date", "Creation Date", "Registry Expiry Date", "Registrar", "Registrar IANA ID", "Registrar Abuse Contact Email", "Registrar Abuse Contact Phone", "Domain Status", "Name Server", "DNSSEC", "Registrar Registration Expiration Date", "Domain Status0", "Domain Status1", "Domain Status2", "Domain Status3", "Domain Status4", "Domain Status5", "Registrant Organization", "Registrant State/Province", "Registrant Country", "Registrant Email", "Admin Organization", "Admin State/Province", "Admin Country", "Admin Email", "Tech Organization", "Tech State/Province", "Tech Country", "Tech Email", "Name Server0", "Name Server1", "Name Server2", "Name Server3", "URL of the ICANN WHOIS Data Problem Reporting System");
	   $out1=rawdata($whoisresult);
       $whois=array(); 
       $count=0;
       $concat="(NULL,";
		foreach($out1 as $x => $x_value) {
			if(in_array($x, $col)){
				$ind=array_search($x,$col,true);
				$x = str_replace(' ', '_', $x);
				$x = str_replace('/', '_', $x);
				$x_value=str_replace('(','  ', $x_value);
				$x_value=str_replace(')','  ', $x_value);
				$col[$ind]=$x;

				$whois[$x]=$x_value;
				
			}
		}
		for($i=0;$i<sizeof($col);$i++){
			if(array_key_exists($col[$i], $whois))
			{
				$x=$col[$i];
				$concat.="'".$whois[$x]."'".",";
				
			}
			else{
				$concat.="NULL".",";
			}
				
		}
		$filename_whois=date("d-m-y")."_".date("h:i:s").".txt";
		$path_whois=put_file($target,$mode,"Whois",$filename_whois,$whoisoutput);
		$s1="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ('$userid','Whois','$path_whois')";
		if (mysqli_query($conn, $s1)) {
			//echo "Whois record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*$sql="INSERT INTO `easy_1_whois`(`id`, `Domain_Name`, `Registry_Domain_ID`, `Registrar_WHOIS_Server`, `Registrar_URL`, `Updated_Date`, `Creation_Date`, `Registry_Expiry_Date`, `Registrar`, `Registrar_IANA_ID`, `Registrar_Abuse_Contact_Email`, `Registrar_Abuse_Contact_Phone`, `Domain_Status`, `Name_Server`, `DNSSEC`, `Registrar_Registration_Expiration_Date`, `Domain_Status0`, `Domain_Status1`, `Domain_Status2`, `Domain_Status3`, `Domain_Status4`, `Domain_Status5`, `Registrant_Organization`, `Registrant_State_Province`, `Registrant_Country`, `Registrant_Email`, `Admin_Organization`, `Admin_State_Province`, `Admin_Country`, `Admin_Email`, `Tech_Organization`, `Tech_State_Province`, `Tech_Country`, `Tech_Email`, `Name_Server0`, `Name_Server1`, `Name_Server2`, `Name_Server3`, `URL_of_the_ICANN_WHOIS_Data_Problem_Reporting_System`) VALUES".$concat.")";
		
		$sql=substr($sql, 0, -2);
		$sql.=")";
		if (mysqli_query($conn, $sql)) {
			echo "Whois record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}*/
		//2nd tool
		
		$nslookupoutput = "2. Nslookup \n".shell_exec("nslookup '$target'");
		$nslookupresult = explode("\n",$nslookupoutput);
		$col2=array("Server","Address","Name0","Address0","Name1","Address1");
		$out2=rawdata($nslookupresult);
		$nslookup=array();
		$count2=0;
		$concat2="(NULL,";
		foreach($out2 as $x => $x_value) {
			if(in_array($x, $col2)){
				$ind=array_search($x,$col2,true);
				$x = str_replace(' ', '_', $x);
				$x = str_replace('/', '_', $x);
				$col2[$ind]=$x;
				$nslookup[$x]=$x_value;
			}
		}
		for($i=0;$i<sizeof($col2);$i++){


			if(array_key_exists($col2[$i], $nslookup))
			{
				$x=$col2[$i];
				$concat2.="'".$nslookup[$x]."'".",";
				
			}
			else{
				$concat2.="NULL".",";
			}
				
		}
		$sql1="INSERT INTO `easy_2_nslookup`(`id`, `Server`, `Address`, `Name0`, `Address0`, `Name1`, `Address1`) VALUES".$concat2;
		$sql1=substr($sql1, 0, -1);
		$sql1.=")";
		$filename_nslookup=date("d-m-y")."_".date("h:i:s").".txt";
		$path_nslookup=put_file($target,$mode,"Nslookup",$filename_nslookup,$nslookupoutput);
		$s2="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'nsLookUp','$path_nslookup')";
		if (mysqli_query($conn, $s2)) {
			//echo "NsLookUp record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql1)) {
			echo "Nslookup record created successfully\n";
		} else {
			//echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
		}*/

		//3rd tool
		$doutput = "3 Dmitry \n".shell_exec("dmitry -s '$target'");
		$dresult = explode("\n",$doutput);

		$out3=array();
		$cnt=0;
		$hn=-1;
		$hi=-1;
		foreach ($dresult as $line){
			$ps = explode(':',$line);
			if($ps[0]=="HostIP" || $ps[0]=="HostName"){
				if($ps[0]=="HostIP"){
					if($hi==-1){
						$out3[$ps[0]]=$ps[1];
						$hi+=1;
					}
					else{
						$out3[$ps[0].$hi]=$ps[1];
						$hi+=1;
					}
				}
				if($ps[0]=="HostName"){
					if($hn==-1){
						$out3[$ps[0]]=$ps[1];
						$hn+=1;
					}
					else{
						$out3[$ps[0].$hn]=$ps[1];
						$hn+=1;
					}
				}
			
			
		}
			//print_r($ps);

		}
		$temp=array();
		$temp["HostIP"]=$out3["HostIP"];
		$temp["HostName"]=$out3["HostName"];
		unset($out3["HostIP"]);
		unset($out3["HostName"]);
		$myjson=json_encode($out3);
		$hostname=$temp["HostName"];
		$hostip=$temp["HostIP"];
		$sql3="INSERT INTO `easy_3_dmitry`(`id`, `HostIP`, `HostName`, `subdomain`) VALUES (NULL,'$hostip','$hostname','$myjson')";
		$filename_dmitry=date("d-m-y")."_".date("h:i:s").".json";
		$path_dmitry=put_file($target,$mode,"Dmirty",$filename_dmitry,$myjson);
		$s3="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'Dmitry','$path_dmitry')";
		if (mysqli_query($conn, $s3)) {
			//echo "Dmitry record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		//echo $sql3;
		/*if (mysqli_query($conn, $sql3)) {
			echo "Dmitry record created successfully\n";
		} else {
			echo "Error: " . $sql3 . "<br>" . mysqli_error($conn);
		}*/



		//4th tool
		$niktooutput = shell_exec("nikto -h '$target'");
		 $niktoresult = explode("\n",$niktooutput);
		 $out4=removenikto($niktoresult);
		 $col4=array("Target IP", "Target Hostname", "Target Port", "Start Time", "Server", "Root page / redirects to", "Allowed HTTP Methods", "Scan terminated","End Time","Other Info");
		 $count=0;
		 $nikto=array();
         $concat4="(NULL,";
		 foreach($out4 as $x => $x_value) {
			if(in_array($x, $col4)){
				$ind=array_search($x,$col4,true);
				$x = str_replace(' ', '_', $x);
				$x = str_replace('/', '_', $x);
				$x_value=str_replace('(','  ', $x_value);
				$x_value=str_replace(')','  ', $x_value);
				$col4[$ind]=$x;

				$nikto[$x]=$x_value;
		
			}
		}
		
		for($i=0;$i<sizeof($col4);$i++){


			if(array_key_exists($col4[$i], $nikto))
			{
				$x=$col4[$i];
				$concat4.="'".$nikto[$x]."'".",";
				
			}
			else{
				$concat4.="NULL".",";
			}
				
		}
		
		$sql4="INSERT INTO `easy_4_nikto`(`id`, `Target_IP`, `Target_hostname`, `Target_Port`, `Start_Time`, `Server`, `root_page_redirects_to`, `Allowed_HTTP_Methods`, `Scan_terminated`, `End_Time`,`Other_Info`) VALUES ".$concat4;
		$filename_nikto=date("d-m-y")."_".date("h:i:s").".txt";
		$path_nikto=put_file($target,$mode,"Nikto",$filename_nikto,$niktooutput);
		$sql4=substr($sql4, 0, -1);
		$sql4.=")";
		$s4="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'Nikto','$path_nikto')";
		if (mysqli_query($conn, $s4)) {
			//echo "Nikto record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		
		/*if (mysqli_query($conn, $sql4)) {
			echo "Nikto record created successfully\n";
		} else {
			//echo "Error: " . $sql4 . "<br>" . mysqli_error($conn);
		}*/
		

		//5th tool

	    $sublistoutput = "5. sublist3r  \n".shell_exec("sublist3r -d '$target' -v");
		$sublistresult = removeasci(explode("\n",$sublistoutput));
		$sublist=srawdata($sublistresult);
		$myjosn1=json_encode($sublist);
		//echo $myjosn1;
		$filename_sublist3r=date("d-m-y")."_".date("h:i:s").".json";
		$path_sublist3r=put_file($target,$mode,"Sublist3r",$filename_sublist3r,$myjosn1);
		$sql5="INSERT INTO `easy_5_sublist3r`(`id`, `target`, `sub_domains`) VALUES (NULL,'$target', '$myjosn1')";
		$s5="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'sublist3r','$path_sublist3r')";
		if (mysqli_query($conn, $s5)) {
			//echo "Sublist3r record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		//echo $sql5;

		/*if (mysqli_query($conn, $sql5)) {
			echo "Sublist3r record created successfully\n";
		} else {
			echo "Error: " . $sql5 . "<br>" . mysqli_error($conn);
		}*/




		//6th tool
		$joomscan = "6. Joomscan \n".shell_exec("joomscan -u https://'$target'");
		$joomresult=explode("\n",removeasci($joomscan));
		$col6=array("FireWall Detector", "Detecting Joomla Version", "Core Joomla Vulnerability", "Full Path Disclosure (FPD)", "Checking apache info/status files", "admin finder", "Checking robots.txt existing","Finding common backup files name", "Finding common log files name", "Checking sensitive config.php.x file ");
		$joomoutput=array();
		$concat6="(NULL,'$target',";
		for($i=0;$i<sizeof($joomresult);$i++){
			if(startsWith($joomresult[$i],"[+]")){
				$key=trim(substr($joomresult[$i],3));
				$ind=array_search($key,$col6,true);
				$key=str_replace(' ', '_', $key);
				$key=str_replace('/', '_', $key);
				$key=str_replace('.', '_', $key);
				$col6[$ind]=$key;
				$joomoutput[$key]="";
				for($j=$i+1;$j<sizeof($joomresult);$j++){
					if(startsWith($joomresult[$j],"[++]")){
						$value=trim(substr($joomresult[$j], 4));
						if($joomoutput[$key]==""){
							$joomoutput[$key].=$value;
						}
						else{
						$joomoutput[$key].=",".$value;
						}
					}
					else{
						break;
					}
				}
			}
		}
		for($i=0;$i<sizeof($col6);$i++){


			if(array_key_exists($col6[$i], $joomoutput))
			{
				$x=$col6[$i];
				$concat6.="'".$joomoutput[$x]."'".",";
				
			}
			else{
				$concat6.="NULL".",";
			}
				
		}
		$sql6="INSERT INTO `easy_6_joomscan`(`id`, `target`, `FireWall_Detector`, `Detecting_Joomla_Version`, `Core_Joomla_Vulnerability`, `Full_Path_Disclosure`, `Checking_apache_info_status_files`, `admin_finder`, `checkinh_robots_txt_existing`, `finding_common_backup_files_name`, `finding_common_log_files_name`, `checkinh_sensitive_config_php_x_file`) VALUES ".$concat6;
		$filename_joomscan=date("d-m-y")."_".date("h:i:s").".txt";
		$path_joomscan=put_file($target,$mode,"Joomscan",$filename_joomscan,$joomscan);
		$sql6=substr($sql6, 0, -1);
		$sql6.=")";
		$s6="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'joomscan','$path_joomscan')";
		if (mysqli_query($conn, $s6)) {
			//echo "JoomScan record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql6)) {
			echo "Joomscan record created successfully\n";
		} else {
			echo "Error: " . $sql6 . "<br>" . mysqli_error($conn);
		}*/
		
		//7th tool

		$WpScanoutput .= "7. Wpscan \n".shell_exec("wpscan --url https://'$target'");
		$WpScanresult2 = explode("[+]",$WpScanoutput,100);
		$out5 = replace2(removeasci($WpScanresult2));
		unset($out5[0]);
		unset($out5[2]);
		$jsondata7=json_encode($out5);
		$sql7="INSERT INTO `easy_7_wpscan`(`id`, `target`, `wpinfo`) VALUES (NULL,'$target','$jsondata7')";
		$filename_wpscan=date("d-m-y")."_".date("h:i:s").".json";
		$path_wpscan=put_file($target,$mode,"Wpscan",$filename_wpscan,$jsondata7);
		$s7="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'WpScan','$path_wpscan')";
		if (mysqli_query($conn, $s7)) {
			//echo "WpScan record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql7)) {
			echo "Wpscan record created successfully\n";
		} else {
			echo "Error: " . $sql7 . "<br>" . mysqli_error($conn);
		}*/
		
		//8th tool
		$ports=array(80,21,22,23,25,53,443,110,135,137,138,139,1433,1434);
		$fres=array();
		for($i=0;$i<sizeof($ports);$i++){
		$netcatoutput = "NetCat \n".shell_exec("nc -zv '$target' '$ports[$i]'");
		$netcatresult = removeasci(explode("\n",$netcatoutput));
		for($j=0;$j<sizeof($netcatresult);$j++){
			if(startsWith($netcatresult[$j],"Ncat: Connected to")){
				$fres[$ports[$i]]=str_replace("Ncat: ", "", $netcatresult[$j]);
			}
		}
		}
		$ifres=json_encode($fres);
		$sql8="INSERT INTO `easy_8_netcat`(`id`, `target`, `open_ports`) VALUES (NULL,'$target','$ifres')";
		$filename_netcat=date("d-m-y")."_".date("h:i:s").".json";
		$path_netcat=put_file($target,$mode,"Netcat",$filename_netcat,$ifres);
		$s8="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'NetCat','$path_netcat')";
		if (mysqli_query($conn, $s8)) {
			//echo "Netcat record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql8)) {
			echo "NetCat record created successfully\n";
		} else {
			echo "Error: " . $sql8 . "<br>" . mysqli_error($conn);
		}*/

		

		//9th tool
		$infoga_path=getcwd()."/module/Infoga/infoga.py";
		$filename2=$target.".txt";
		$infoga = shell_exec("python3 '$infoga_path' --domain '$target' -s all --breach --report '$filename2' -v 3 2>&1");
		$path=getcwd()."/".$filename2;
		$infogafile = fopen($path, "r") or die("Unable to open file!");
		$var=fread($infogafile,filesize($path));
		fclose($infogafile);
		$var=explode("\n", $var);
		$var=str_replace("(", " ", $var);
		$var=str_replace(")", " ", $var);
		$outinfoga=array();
		$e=0;
		foreach ($var as $line) {
			$ps=explode("Email:", $line);
			for($i=1;$i<sizeof($ps);$i++){
				$outinfoga["Email".$e.":"]=$ps[$i];
				$e+=1;
			}
		}
		unlink($path);
		$infogajson=json_encode($outinfoga);
		$sql9="INSERT INTO `easy_9_infoga`(`id`, `target`, `infoga_json`) VALUES (NULL,'$target','$infogajson')";
		$filename_infoga=date("d-m-y")."_".date("h:i:s").".json";
		$path_infoga=put_file($target,$mode,"Infoga",$filename_infoga,$infogajson);
		$s9="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'infoga','$path_infoga')";
		if (mysqli_query($conn, $s9)) {
			//echo "Infoga record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql9)) {
			echo "Infoga record created successfully\n";
		} else {
			echo "Error: " . $sql9 . "<br>" . mysqli_error($conn);
		}*/

	
		//10th tool

		$wascan_path=getcwd()."/module/wascan/wascan.py";
		$wascan_output = "WAScan \n".shell_exec("python  '$wascan_path' -u https://'$target' -s 0  2>&1");
		$wascan_result = removeasci(explode("\n",$wascan_output));
		$wascanout=array();
		for($i=0;$i<sizeof($wascan_result);$i++){
			if(startsWith($wascan_result[$i],"[+]")){
				$line=trim(substr($wascan_result[$i],3));
				$ps=explode(":", $line);
				if(sizeof($ps)>2){
					for($j=2;$j<sizeof($ps);$j++){
						$ps[1].=$ps[$j];
					}
				}
				$wascanout[$ps[0]]=$ps[1];	
			}
		}
		$col10=array("URL","Starting","Server");
		$concat10="(NULL,";
		for($i=0;$i<sizeof($col10);$i++){


			if(array_key_exists($col10[$i], $wascanout))
			{
				$x=$col10[$i];
				$concat10.="'".trim($wascanout[$x])."'".",";
				
			}
			else{
				$concat10.="NULL".",";
			}
				
		}
		$sql10="INSERT INTO `easy_10_wascan`(`id`, `target`, `Start`, `Server`) VALUES".$concat10;
		
		$sql10=substr($sql10, 0, -1);
		$sql10.=")";
		$filename_wascan=date("d-m-y")."_".date("h:i:s").".json";
		$path_wascan=put_file($target,$mode,"Wascan",$filename_wascan,json_encode($wascanout));
		$s10="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'WAscan',$path_wascan)";
		if (mysqli_query($conn, $s10)) {
			//echo "WAScan record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql10)) {
			echo "WAScan record created successfully\n";
		} else {
			echo "Error: " . $sql10 . "<br>" . mysqli_error($conn);
		}*/

		
		//11th tool
		
		$nmap = shell_exec("nmap --top-ports 20 '$target' ");
		$nmapresult = explode("\n",$nmap);
		$nmapresult=json_encode($nmapresult);
		$sql11="INSERT INTO `easy_11_nmap`(`id`,`target`, `nmap_json`) VALUES (NULL,'$target','$nmapresult')";
		$filename_nmap=date("d-m-y")."_".date("h:i:s").".json";
		$path_nmap=put_file($target,$mode,"Nmap",$filename_nmap,$nmapresult);
		$s11="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'NMap','$path_nmap')";
		if (mysqli_query($conn, $s11)) {
			//echo "NMap record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql11)) {
			echo "nmap record created successfully\n";
		} else {
			echo "Error: " . $sql11 . "<br>" . mysqli_error($conn);
		}*/


		//12th tool
		$cmseek_path=getcwd()."/module/CMSeeK/cmseek.py";
		$target="charusat.ac.in";
		$cmseek_output = "CMSeeK \n".shell_exec("python3 '$cmseek_path' -u https://'$target' ");
		$path=getcwd()."/module/CMSeeK/Result/".$target."/cms.json";
		$f=fopen($path, "r");
		$cjson=fread($f,filesize($path));
		fclose($f);
		$sql12="INSERT INTO `easy_12_cmseek`(`id`, `target`, `cms_info`) VALUES (NULL,'$target','$cjson')";
		$filename_cmseek=date("d-m-y")."_".date("h:i:s").".json";
		$path_cmseek=put_file($target,$mode,"CMSeeK",$filename_cmseek,$cjson);
		$s12="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'cmseek','path_cmseek')";
		if (mysqli_query($conn, $s12)) {
			//echo "CMSeeK record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql12)) {
			echo "CMSeeK record created successfully\n";
		} else {
			echo "Error: " . $sql12 . "<br>" . mysqli_error($conn);
		}*/


		//13th tool
		$identYwaf_path=getcwd()."/module/identYwaf/identYwaf.py";
		$identYwaf = "IentYwaf \n".shell_exec("python3 '$identYwaf_path' '$target' ");

		$identYwafresult = explode("\n",$identYwaf);
		$identout=array();
		for($i=0;$i<sizeof($identYwafresult);$i++){
			if(startsWith($identYwafresult[$i],"[+]")){
				$line=trim(substr($identYwafresult[$i],3));
				$ps=explode(":", $line);
				if(sizeof($ps)>2){
					for($j=2;$j<sizeof($ps);$j++){
						$ps[1].=$ps[$j];
					}
				}
				$identout[$ps[0]]=$ps[1];	
			}
		}
		$identjson=json_encode($identout);
		$identjson=str_replace("'"," ",$identjson);
		$sql13="INSERT INTO `easy_13_ientywaf`(`id`, `target`, `ident_json`) VALUES (NULL,'$target','$identjson')";
		$filename_ientywaf=date("d-m-y")."_".date("h:i:s").".json";
		$path_ientywaf=put_file($target,$mode,"IentYwaf",$filename_ientywaf,$identjson);
		$s13="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'IDenYAF','$path_ientywaf')";
		if (mysqli_query($conn, $s13)) {
			//echo "IndentYAF record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql13)) {
			echo "IentYwaf record created successfully\n";
		} else {
			echo "Error: " . $sql13 . "<br>" . mysqli_error($conn);
		}*/

		//14th tool

		$habu_output = shell_exec("habu.http.headers https://'$target' && habu.http.tech --format json https://'$target' ");
		$habujson=json_encode($habu_output);
		$sql14="INSERT INTO `easy_14_habu`(`id`, `target`, `habu_json`) VALUES (NULL,'$target','$habujson')";
		$filename_habu=date("d-m-y")."_".date("h:i:s").".json";
		$path_habu=put_file($target,$mode,"Habu",$filename_habu,$habujson);
		$s14="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'habu','path_habu')";
		if (mysqli_query($conn, $s14)) {
			//echo "Habu record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql14)) {
			echo "Habu record created successfully\n";
		} else {
			echo "Error: " . $sql14 . "<br>" . mysqli_error($conn);
		}*/

		//15th tool
		
		$infosploit_path=getcwd()."/module/InfoSploit/Infosploit.py";
		$InfoSploit2 = shell_exec("python '$infosploit_path' 3 '$target'");

		$InfoSploitresult2 = removeasci(explode("\n",$InfoSploit2));
		$out=json_encode($InfoSploitresult2);
		$infoout2=array();
		for($i=0;$i<sizeof($InfoSploitresult2);$i++){
			$line=$InfoSploitresult2[$i];
			if($line!=""){
			$ps=explode(":",$line);
			//print_r($ps);
			$infoout2[$ps[0]]=$ps[1];
			}
			
		}
		$infoout2json=json_encode($infoout2);
		$InfoSploit3 = shell_exec("python '$infosploit_path' 9 '$target' ");
		$InfoSploitresult3 = removeasci(explode("\n",$InfoSploit3));
		$infoout3=array();
		for($i=0;$i<sizeof($InfoSploitresult3);$i++){
			$line=$InfoSploitresult3[$i];
			if($line!=""){
			$ps=explode(",",$line);
			
			$infoout3[$ps[0]]=$ps[1];
			}
			
		}
		$infoout3json=json_encode($infoout3);
		

		$InfoSploit4 = shell_exec("python '$infosploit_path' 10 '$target' ");
		$InfoSploitresult4 = removeasci(explode("\n",$InfoSploit4));
		$infoout4json=json_encode($InfoSploitresult4);


		$sql15="INSERT INTO `easy_15_infosploit`(`id`, `target`, `getip_lookup`, `host_finder`, `ip_locator`) VALUES (NULL,'$target','$infoout2json','$infoout3json','$infoout4json')";
		$timestamp_infosploit=date("d-m-y")."_".date("h:i:s");
		$filename_infosploit1=$timestamp_infosploit."getip_lookup".".json";
		$path_infosploit1=put_file($target,$mode,"Infosploit",$filename_infosploit1,$infoout2json);

		$filename_infosploit2=$timestamp_infosploit."host_finder".".json";
		$path_infosploit2=put_file($target,$mode,"Infosploit",$filename_infosploit2,$infoout3json);

		$filename_infosploit3=$timestamp_infosploit.date("h:i:s")."ip_locator".".json";
		$path_infosploit3=put_file($target,$mode,"Infosploit",$filename_infosploit3,$infoout4json);
		$s15="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'infosploit','path_infosploit3')";
		if (mysqli_query($conn, $s1)) {
			//echo "Infosploit record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}

		/*if (mysqli_query($conn, $sql15)) {
			echo "Infosploit record created successfully\n";
		} else {
			echo "Error: " . $sql15 . "<br>" . mysqli_error($conn);
		}*/
		


		//16th tool
		$gorecon_path=getcwd()."/module/Gorecon/gorecon.go";
		$Goreconoutput = shell_exec("go run '$gorecon_path' --url '$target' 2>&1");
		$Goreconresult = explode("\n",$Goreconoutput);
		$jsonobj=json_encode($Goreconresult);
		$jsonobj=str_replace("'"," ",$jsonobj);
		$filename_Gorecon=date("d-m-y")."_".date("h:i:s").".json";
		$path_Gorecon=put_file($target,$mode,"Gorecon",$filename_Gorecon,$jsonobj);
		$sql16="INSERT INTO `easy_16_gorecon`(`id`, `target`, `gorecon_path`) VALUES (NULL,'$target','$path_Gorecon')";
		$s16="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'Gorecon','path_Gorecon')";
		if (mysqli_query($conn, $s16)) {
			//echo "Gorecon record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		
		/*if (mysqli_query($conn, $sql16)) {
			echo "gorecon record created successfully\n";
		} else {
			echo "Error: " . $sql16 . "<br>" . mysqli_error($conn);
		}*/

		//17th tool
		$filename=$target.".json";
		$whatweboutput = " \n".shell_exec("whatweb -v '$target' --log-json='$filename' ");
		$path=getcwd().$filename;
		$f=fopen($path, "r");
		$result = explode("\n",$whatweboutput);
		$whatwebjson=fread($f,filesize($path));
		fclose($f);
		$filename_whatweb=date("d-m-y")."_".date("h:i:s").".json";
		$path_whatweb=put_file($target,$mode,"Whatweb",$filename_whatweb,$whatwebjson);
		$sql17="INSERT INTO `easy_17_whatweb`(`id`, `target`, `whatweb_path`) VALUES (NULL,'$target','$path_whatweb')";
		$s17="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'Whatweb','path_whatweb')";
		if (mysqli_query($conn, $s17)) {
			//echo "WhatWeb record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		
		/*if (mysqli_query($conn, $sql17)) {
			echo "whatweb record created successfully\n";
		} else {
			echo "Error: " . $sql17 . "<br>" . mysqli_error($conn);
		}*/

		
		//18th tool
		$lbd_path=getcwd()."/module/lbd/lbd";
		$lbd_output = trim(shell_exec("'$lbd_path' '$target'"));
		$lbd_result = removeasci(explode("\n",$lbd_output));
		$lbdout=array();
		for($i=0;$i<sizeof($lbd_result);$i++){
			$line=$lbd_result[$i];
      
			if($line!=""){
				$ps=explode(":",$line);
				$lbdout[trim($ps[0])]=trim($ps[1]);
			}
		}
		$lbd=json_encode($lbdout);
		$sql18="INSERT INTO `easy_18_lbd`(`id`, `target`, `lbd_json`) VALUES (NULL,'$target','$lbd')";
		$filename_lbd=date("d-m-y")."_".date("h:i:s").".json";
		$path_lbd=put_file($target,$mode,"LBD",$filename_lbd,$lbd);
		$s18="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'lbd','$path_lbd')";
		if (mysqli_query($conn, $s18)) {
			//echo "lbd record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql18)) {
			echo "lbd record created successfully\n";
		} else {
			echo "Error: " . $sql18 . "<br>" . mysqli_error($conn);
		}*/


		//19th tool
		$nmap_output = shell_exec("nmap -Pn --script vuln '$target' ");
		$nmap_result = explode("\n",$nmap_output);
		$nmap_json=json_encode($nmap_result);
		$filename_nmap1=date("d-m-y")."_".date("h:i:s").".json";
		$path_nmap1=put_file($target,$mode,"Nmap",$filename_nmap1,$nmap_json);
		$sql19="INSERT INTO `easy_19_nmap`(`id`, `target`, `nmap_path`) VALUES (NULL,'$target','$path_nmap1')";
		$s19="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'nmap1','$path_nmap1')";
		if (mysqli_query($conn, $s19)) {
			//echo "nmap1 record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		
		/* (mysqli_query($conn, $sql19)) {
			echo "nmap record created successfully\n";
		} else {
			echo "Error: " . $sql19 . "<br>" . mysqli_error($conn);
		}*/

		
		//20th tool

		$breacher_path=getcwd()."/module/Breacher/breacher.py";
		$breacheroutput = shell_exec("python3 '$breacher_path' -u '$target' --type php 2>&1");
		$breacherresult = explode("\n",$breacheroutput);
		$breacher=json_encode($breacherresult);
		$breacher=str_replace("'", " ", $breacher);

		$sql20="INSERT INTO `easy_20_breacher`(`id`, `target`, `breacher_json`) VALUES (NULL,'$target','$breacher')";
		$filename_breacher=date("d-m-y")."_".date("h:i:s").".json";
		$path_breacher=put_file($target,$mode,"Breacher",$filename_breacher,$breacher);
		$s20="INSERT INTO `toolData`(`id`, `tool_Name`, `file_Name`) VALUES ($userid,'Breacher','$path_breacher')";
		if (mysqli_query($conn, $s20)) {
			//echo "Breacher record created successfully\n";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		/*if (mysqli_query($conn, $sql20)) {
			echo "breacher record created successfully\n";
		} else {
			echo "Error: " . $sql20 . "<br>" . mysqli_error($conn);
		}*/

		

		echo "You are redirected to the Report";

		break;
		
	default:

		# code...
		break;
}


?>
