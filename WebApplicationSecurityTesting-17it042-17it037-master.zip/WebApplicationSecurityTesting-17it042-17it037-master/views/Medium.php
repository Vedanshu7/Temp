<?php
//ini_set('display_errors',0);
include("db.php");
#require("/opt/lampp/htdocs/BadMod/Functions.php");
function get_domain($url)
{
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : $pieces['path'];
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}
function is_valid_domain($url){

    $validation = FALSE;
    /*Parse URL*/    
    $urlparts = parse_url(filter_var($url, FILTER_SANITIZE_URL));

    /*Check host exist else path assign to host*/    
    if(!isset($urlparts['host'])){
        $urlparts['host'] = $urlparts['path'];
    }

    if($urlparts['host']!=''){
        /*Add scheme if not found*/        if (!isset($urlparts['scheme'])){
        $urlparts['scheme'] = 'http';
        }

        /*Validation*/        
    if(checkdnsrr($urlparts['host'], 'A') && in_array($urlparts['scheme'],array('http','https')) && ip2long($urlparts['host']) === FALSE){ 
        $urlparts['host'] = preg_replace('/^www\./', '', $urlparts['host']);
        $url = $urlparts['scheme'].'://'.$urlparts['host']. "/";            

            if (filter_var($url, FILTER_VALIDATE_URL) !== false && @get_headers($url)) {
                $validation = TRUE;
            }
        }
    }

    return $validation;

}

function replace($string){
	$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\[\]\.\(\)%&-]/s', '', $string);
    return $string;
}


function replace1($string){
	$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\[\]\.\(\)%&]/s', '', $string);
    return $string;
}

function rawdata($result)
{
	$out = array();
	$other=array();
	$ds=0;
	$ns=0;
	$ad=-1;
	$n=0;
	foreach ($result as $line){
		if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }

		if(substr_count($line,":") > 1){
		  $loc=strpos($line,":");
          $ps = str_split($line,$loc+1);
          
          if(sizeof($ps)>2){
          	for($i=2;$i<sizeof($ps);$i++){
          		$ps[1].=$ps[$i];
          	}
          }
          $temp=explode(":", $ps[0]);
          if($temp[0]=="Domain Status"){
          	$temp[0]=$temp[0].$ds;
          	$ds+=1;
          }
          if($temp[0]=="Name Server"){
          	$temp[0]=$temp[0].$ns;
          	$ns+=1;
          }
          if($temp[0]=="Address"){
          	 if($ad==-1){
          	 	$ad+=1;
          	 }
          	 else{
          	$temp[0]=$temp[0].$ad;
          	$ad+=1;
          }
          }
          if($temp[0]=="Name"){
          	$temp[0]=$temp[0].$n;
          	$n+=1;
          }
          $out[trim($temp[0])] =trim(replace($ps[1]));
		  
		  
		}
		else if(substr_count($line,":") < 1){
			$other.=$line.",";
		}
		else{
		$ps = explode(':',$line);
		//echo $ps;
		if($ps[0]=="Domain Status"){
          	$ps[0]=$ps[0].$ds;
          	$ds+=1;
          }
          if($ps[0]=="Name Server"){
          	$ps[0]=$ps[0].$ns;
          	$ns+=1;
          }
          if($ps[0]=="Address"){
          	if($ad==-1){
          	 	$ad+=1;
          	 }
          	 else{
          	$ps[0]=$ps[0].$ad;
          	$ad+=1;
          }
          }
          if($ps[0]=="Name"){
          	$ps[0]=$ps[0].$n;
          	$n+=1;
          }
		$out[trim($ps[0])] =trim(replace($ps[1]));	
		}
		}
		print_r("<pre>");
		 print_r($other);
		 print_r("<pre>");		
		return $out;
}
function srawdata($result)
{
	
	$other="";
	$out=array();
	foreach ($result as $line){
		if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }
		if(substr_count($line,":") < 1){
			$other.=$line.",";
		}
		
		}
		preg_match_all('#[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $other, $match);
		for($i=0;$i<sizeof($match[0]);$i++){
			if(get_domain($match[0][$i])!=false){
				array_push($out,$match[0][$i]);
			}
		}
		return $out;
}
function removenikto($result){
	$out = array();
	
	foreach ($result as $line){
		if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }

		if(substr_count($line,":") > 1){
		  $loc=strpos($line,":");
          $ps = str_split($line,$loc+1);
          
          if(sizeof($ps)>2){
          	for($i=2;$i<sizeof($ps);$i++){
          		$ps[1].=$ps[$i];
          	}
          }
          $temp=explode(":", $ps[0]);
          
          $out[trim(replace1($temp[0]))] =trim(replace1($ps[1]));
		  
		  
		}
		else if(substr_count($line,":") < 1){
			if(replace1($line)!="" && replace1($line)!=" " && replace1($line)!="Nikto v2.1.6" && replace1($line)!=" Nikto v2.1.6"){
				$out["Other Info"].=replace1($line).",";
			}
			
		}
		else{
		$ps = explode(':',$line);
		//echo $ps;
		
		$out[trim(replace1($ps[0]))] =trim(replace1($ps[1]));	
		}
		}
		
		return $out;
}

function filtersitadel($result){
	foreach ($result as $line){
		if(substr($line, 1, 2) === '+')
		{
			echo $line;
		}
	}
}
function replace2($string){
	$string=preg_replace('/[^a-zA-Z0-9_\/\/\:%\[\]\.\(\)%&\|]/s', '', $string);
    return $string;
}


function removeasci($test){
	$test=preg_replace('#\\x1b[[][^A-Za-z]*[A-Za-z]#', '', $test);
	return $test;
}
function startsWith ($string, $startString) 
{ 
    $len = strlen($startString); 
    return (substr($string, 0, $len) === $startString); 
} 
function put_file($target,$mode,$tool,$filename,$data)
{
	
	while (true) {
	$mainpath = getcwd()."/Output";
	if(is_dir($mainpath)) {
		$mainpath.="/".$target;
		if(is_dir($mainpath)){
			$mainpath.="/".$mode;
			if(is_dir($mainpath)){
				$mainpath.="/".$tool;
				if(is_dir($mainpath)){
					$mainpath.="/".$filename;
					$myfile = fopen($mainpath, "w") or die("Unable to open file!");
					fwrite($myfile, $data);
					fclose($myfile);
					return $mainpath;
					break;
				}
				else{
					mkdir($mainpath);
				}
			}
			else{
				mkdir($mainpath);
			}
		}
		else{
			mkdir($mainpath);
		}
	} else {
		mkdir($mainpath);
	}
}
}

function replace4($string){
$string=preg_replace('/[^a-zA-Z0-9_\/\/\:%\.\(\)%&\{}|]/s', '', $string);
    return $string;
}
function remove_http($url) {
    $disallowed = array('http://', 'https://');
    foreach($disallowed as $d) {
       if(strpos($url, $d) === 0) {
          return str_replace($d, '', $url);
       }
    }
    return $url;
 }
 
$target=remove_http($_GET['target']);
$mode="Medium";
$str = exec("ping -c 1 '$target'");
if ($result == 0){
  echo "ping succeeded";
}else{
  $mode="";
}


switch ($mode) {
	case "Medium":
	
	//1st tool
	$finalrecon_path=getcwd()."/module/FinalRecon/finalrecon.py";
	$finalrecon_output = "Finalrecon \n".shell_exec("python3 '$finalrecon_path' --headers --sslinfo --whois --crawl --dns https://'$target' -o txt ");
	$finalrecon_result = explode("\n",$finalrecon_output);
	$inter_path=getcwd()."/module/FinalRecon/dumps/".$target.".txt";
	$f=fopen($inter_path, "r");
	$final_json=fread($f,filesize($inter_path));
	fclose($f);
	$filename_finalracon=date("d-m-y")."_".date("h:i:s").".json";
	$path_finalracon=put_file($target,$mode,"Final_Racon",$filename_finalracon,$final_json);
	$sql1="INSERT INTO `medium_1_finalrecon`(`id`, `target`, `recon_path`) VALUES (NULL,'$target','$path_finalracon')";
	if (mysqli_query($conn, $sql1)) {
		echo "final racon record created successfully\n";
	} else {
		echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
	}



	//2nd tool
	$filename_nikto=$target.'.json';
	$niktooutput = shell_exec("nikto  -o '$filename_nikto' -Format json -Tuning x -h '$target'");
	$niktoresult = explode("\n",$niktooutput);
	$path_nikto=getcwd().$filename_nikto;
	$f=fopen($path_nikto, "r");
	$niktojson=fread($f,filesize($path_nikto));
	fclose($f);
	unlink($filename_nikto);
	$filename_nikto=date("d-m-y")."_".date("h:i:s").".json";
	$ppath=put_file($target,$mode,"Nikto",$filename_nikto,$niktojson);
	$sql2="INSERT INTO `medium_2_nikto`(`id`, `target`, `nikto_json`) VALUES (NULL,'$target','$niktojson')";
	if (mysqli_query($conn, $sql2)) {
		echo "nikto record created successfully\n";
	} else {
		echo "Error: " . $sql2. "<br>" . mysqli_error($conn);
	}


	//3rd tool
	$gobuster_path=getcwd()."/module/Gobuster/gobuster";
	$wl_path=getcwd()."/module/Gobuster/wordlists/wl_big.txt";
	$filename_gobuster=date("d-m-y")."_".date("h:i:s").".json";
	$gobuster = shell_exec("'$gobuster_path' dir -u https://'$target'/ -w '$wl_path' -q -n -e");
	$gobusterresult = explode("\n",$gobuster);
	$gobusterjson=json_encode($gobusterresult);
	$sql3="INSERT INTO `medium_3_gobuster`(`id`, `target`, `gobuster_json`) VALUES (NULL,'$target','$gobusterjson')";
	$p1path=put_file($target,$mode,"Gobuster",$filename_gobuster,$gobusterjson);
	if (mysqli_query($conn, $sql3)) {
		echo "gorecon record created successfully\n";
	} else {
		echo "Error: " . $sql3 . "<br>" . mysqli_error($conn);
	}


	//4th tool
	$adminfinder_path=getcwd()."/module/admin-san/admin-san.py";
	$adminfinder_output = "adminfinder \n".shell_exec("python3 '$adminfinder_path' '$target'");
	$adminfinder_result = replace4(removeasci(explode("\n",$adminfinder_output )));
	$adminfinder_out=array();
	foreach ($adminfinder_result as $line) {
		if (startsWith($line,'h')) {
			array_push($adminfinder_out, $line);
		}
	}
	$adminfinder_json=json_encode($adminfinder_out);
	$filename_adminfinder=date("d-m-y")."_".date("h:i:s").".json";
	$p13path=put_file($target,"Medium","Admin_Finder",$filename_adminfinder,$adminfinder_json);
	$sql4="INSERT INTO `medium_4_adminsan`(`id`, `target`, `admin_json`) VALUES (NULL,'$target','$adminfinder_json')";
	if (mysqli_query($conn, $sql4)) {
		echo "adminfinder record created successfully\n";
	} else {
		echo "Error: " . $sql4. "<br>" . mysqli_error($conn);
	}
	

	//5th tool
	$spoofcheck_path=getcwd()."/module/spoofcheck/spoofcheck.py";
	$SpoofCheck = " SpoofCheck \n".shell_exec("python '$spoofcheck_path' https://'$target'");
	print_r($SpoofCheck);
	$SpoofCheckresult = explode("]",$SpoofCheck);
	foreach ($SpoofCheckresult as $key => $value) {
		if(strpos($value, "mailto") !== false){
		//$inc=strpos($value, "mailto");
			unset($SpoofCheckresult[$key]);
		}
		else{
			continue;
		}
	}
	$SpoofCheckoutput = end($SpoofCheckresult);
	$filename_spoofcheck=date("d-m-y")."_".date("h:i:s").".txt";
	$p2path=put_file($target,$mode,"SpoofCheck",$filename_spoofcheck,serialize($SpoofCheckoutput));
	$sql5="INSERT INTO `medium_5_spoofcheck`(`id`, `target`, `spoof_check_result`) VALUES (NULL,'$target','$SpoofCheckoutput')";

		if (mysqli_query($conn, $sql5)) {
			echo "SpoofCheck record created successfully\n";
		} else {
			echo "Error: " . $sql5 . "<br>" . mysqli_error($conn);
		}

	
	//6th tool
	$ht2_path=getcwd()."/module/h2t/h2t.py";
	$ht2=shell_exec("python3 '$ht2_path' s '$target'");
	$filename_ht2=date("d-m-y")."_".date("h:i:s").".json";
	$ht2_result=explode("\n",$ht2);
	$goodheader=array();
	$badheader=array();
	$goodheaders=array();
	foreach ($ht2_result as $line) {
		$line=trim($line);
		if(startsWith($line,"[1]")){
			$line=substr($line,3);
			array_push($goodheader,$line);
		}
		else if(startsWith($line,"[2]")){
			$line=substr($line,3);
			array_push($badheader, $line);
		}
		else if(startsWith($line,"[0]")){
			$line=substr($line,3);
			array_push($goodheaders, $line);
		}
	}
	$good_header=json_encode($goodheader);
	$good_headers=json_encode($goodheaders);
	$bad_header=json_encode($badheader);
	$mainarray=array_merge($goodheader,$goodheaders);
	$mainarray=array_merge($mainarray,$badheader);
	$main_json=json_encode($mainarray);
	$p14path=put_file($target,"Medium","H2t",$filename_ht2,$main_json);
	$sql6="INSERT INTO `medium_6_h2t`(`id`, `target`, `good_header`, `good_headers`, `bad_header`) VALUES (NULL,'$target','$good_header','$good_headers','$bad_header')";
	if (mysqli_query($conn, $sql6)) {
		echo "h2t record created successfully\n";
	} else {
		echo "Error: " . $sql6. "<br>" . mysqli_error($conn);
	}

	//7th tool
	$fierce_output = shell_exec("fierce -dns '$target'");
	$filename_fierece=date("d-m-y")."_".date("h:i:s").".txt";
	$path_fierce=put_file($target,"Medium","Fierce",$filename_fierece,$fierce_output);
	$sql7="INSERT INTO `medium_7_fierce`(`id`, `target`, `fierce_path`) VALUES (NULL,'$target','$path_fierce')";
	if (mysqli_query($conn, $sql7)) {
		echo "fierce record created successfully\n";
	} else {
		echo "Error: " . $sql7 . "<br>" . mysqli_error($conn);
	}



	//8th tool
	$vulnx_path=getcwd()."/module/vulnx/vulnx.py";
	$vulnx_output = "Vulnx \n".shell_exec("python3 '$vulnx_path' -u '$target' -w -d");
		$vulnx_result = removeasci(explode("\n", $vulnx_output));
		$sets=array();
		foreach ($vulnx_result as $line) {
			$line=trim($line);
			if(startsWith($line,"[+]")){
				$line=trim(substr($line,3));
				$ps=explode(":", $line);
				if(sizeof($ps)>2){
					for($j=2;$j<sizeof($ps);$j++){
						$ps[1].=$ps[$j];
					}
				}
				$sets[trim($ps[0])]=trim($ps[1]);
			}
		}
		$vulnx_json=json_encode($sets);
		$filename_vulnx=date("d-m-y")."_".date("h:i:s").".json";
		$p3path=put_file($target,$mode,"Vulnx",$filename_vulnx,$vulnx_json);
		$sql8="INSERT INTO `medium_8_vulnx`(`id`, `target`, `vulnx_json`) VALUES (NULL,'$target','$vulnx_json')";

		if (mysqli_query($conn, $sql8)) {
			echo "vulnx record created successfully\n";
		} else {
			echo "Error: " . $sql8 . "<br>" . mysqli_error($conn);
		}

	//9th tool
	$path="";
	$whatwaf_path=getcwd()."/module/WhatWaf/whatwaf.py";
	$whatwaf=shell_exec("python3 '$whatwaf_path' -u https://'$target' -F -J 2>&1");
	$whatwaf_result=explode("\n",$whatwaf);
	foreach ($whatwaf_result as $line) {
		if(startsWith($line,"[INFO]data has been written to file: ")){
			$ps=explode("[INFO]data has been written to file: ",$line);
			$path=$ps[1];
		}
	}
	$whatwaf_json;
	if($path!=""){
		$path=substr($path,1);
		$path=substr($path,0,-1);
		$f=fopen($path, "r");
		$json_file=fread($f,filesize($path));
		fclose($f);
		$whatwaf_json=json_encode($json_file);
	}
	else{
		$temp_json=array("apparent working tampers"=>null,"identified firewall"=>null,"is protected"=>true,"url"=>$target);
		$whatwaf_json=json_encode($temp_json);
	}
	$filename_whatwaf=date("d-m-y")."_".date("h:i:s").".json";
	$p4path=put_file($target,$mode,"WhatWaf",$filename_whatwaf,$whatwaf_json);
	$sql9="INSERT INTO `medium_9_whatwaf`(`id`, `target`, `whatwaf_json`) VALUES (NULL,'$target','$whatwaf_json')";
	if (mysqli_query($conn, $sql9)) {
		echo "whatwaf record created successfully\n";
	} else {
		echo "Error: " . $sql9 . "<br>" . mysqli_error($conn);
	}

	

	//10th tool
	$filename_atscan=date("d-m-y")."_".date("h:i:s").".txt";
	$atscan_path=getcwd()."/module/ATSCAN/atscan.pl";
	$atscan=shell_exec("perl '$atscan_path' -t https://'$target' --lfi");
	$path_atscan=put_file($target,"Medium","Atscan",$filename_atscan,$atscan);
	$sql10="INSERT INTO `medium_10_atscan`(`id`, `target`, `file_path`) VALUES (NULL,'$target','$path_atscan')";
	if (mysqli_query($conn, $sql10)) {
		echo "atscan record created successfully\n";
	} else {
		echo "Error: " . $sql10 . "<br>" . mysqli_error($conn);
	}

	

	//11th tool
	$harvester_path=getcwd()."/module/theHarvester/theHarvester.py";
	$theHarvester = " \n".shell_exec("python3 '$harvester_path' -d '$target' -s -b all");
	$theHarvester_result = removeasci(explode("\n",$theHarvester));
	$flag=false;
	$harvesterout=array();
	foreach ($theHarvester_result as $line) {
		if(startsWith($line,"[*] Searching Shodan")){
			$flag=true;
		}
		if($flag){
			array_push($harvesterout,$line);
		}
	}
	$serializedData = serialize($harvesterout);
	$filename_harvester=date("d-m-y")."_".date("h:i:s").".txt";
	$path_harvester=put_file($target,"Medium","Harvester",$filename_harvester,$serializedData);
	$sql11="INSERT INTO `medium_11_harvester`(`id`,`target`, `file_path`) VALUES (NULL,'$target','$path_harvester')";
	if (mysqli_query($conn, $sql11)) {
		echo "harvester record created successfully\n";
	} else {
		echo "Error: " . $sql11 . "<br>" . mysqli_error($conn);
	}


	//12th tool
	$badmod_path=getcwd()."/module/BadMod/Functions.php";
	require $badmod_path;
	$badmod=reversedns("https://".$target);
	$badmod_result=explode("\n",$badmod);
	$badmodfilter=array();
	foreach ($badmod_result as $line) {
		$ps=explode(",", $line);
		$badmodfilter[trim($ps[0])]=trim($ps[1]);
	}
	$badmod_json=json_encode($badmodfilter);
	$filename_badmod=date("d-m-y")."_".date("h:i:s").".json";
	$p5path=put_file($target,$mode,"BadMod",$filename_badmod,$badmod_json);
	$sql12="INSERT INTO `medium_12_badmod`(`id`, `target`, `badmod_json`) VALUES (NULL,'$target','$badmod_json')";
	if (mysqli_query($conn, $sql12)) {
		echo "parsero record created successfully\n";
	} else {
		echo "Error: " . $sql12 . "<br>" . mysqli_error($conn);
	}
	

	//13th tool
	$striker_path=getcwd()."/module/Striker/striker.py";
	$Striker = shell_exec("python3 '$striker_path' '$target'");
	$Strikerresult = explode("\n",$Striker);
	$striker_json=trim(json_encode($Strikerresult));
	$filename_striker=date("d-m-y")."_".date("h:i:s").".json";
	$p6path=put_file($target,$mode,"Striker",$filename_striker,$striker_json);
	$sql13="INSERT INTO `medium_13_striker`(`id`, `target`, `striker_json`) VALUES (NULL,'$target','$striker_json')";
	if (mysqli_query($conn, $sql13)) {
		echo "striker record created successfully\n";
	} else {
		echo "Error: " . $sql13. "<br>" . mysqli_error($conn);
	}


	
	//14th tool

	$xsstrike_path=getcwd()."/module/XSStrike/xsstrike.py";
	$XSStrike = shell_exec("python3 '$xsstrike_path' -u http://'$target'/?i= ");
	$XSStrikeresult = removeasci(explode("\n",$XSStrike));
	$output_xss=array();
	foreach ($XSStrikeresult as $line) {
		if(startsWith($line,"[+]")){
			$line=trim(substr($line,3));
			$ps=explode(":", $line);
			if(sizeof($ps)>2){
				for($j=2;$j<sizeof($ps);$j++){
					$ps[1].=$ps[$j];
				}
			}
			$output_xss[trim($ps[0])]=trim($ps[1]);
		}
	}
	$XSStrike_json=trim(json_encode($output_xss));
	$filename_xsstrike=date("d-m-y")."_".date("h:i:s").".json";
	$p7path=put_file($target,$mode,"XSStrike",$filename_xsstrike,$XSStrike_json);
	$sql14="INSERT INTO `medium_14_xsstrike`(`id`, `target`, `xsstrike_json`) VALUES (NULL,'$target','$XSStrike_json')";
	if (mysqli_query($conn, $sql14)) {
		echo "xsstrike record created successfully\n";
	} else {
		echo "Error: " . $sql14. "<br>" . mysqli_error($conn);
	}



	//15th tool

	$zoom_path=getcwd()."/module/Zoom/zoom.py";
	$Zoom = " \n".shell_exec("python2 '$zoom_path' --url '$target' --auto");
	$Zoomresult = removeasci(explode("\n",$Zoom));
	$zoom_output=array();
	foreach ($Zoomresult as $line) {
		if(is_valid_domain($line)){
			array_push($zoom_output,$line);
		}
	}
	$zoom_json=json_encode($zoom_output);
	$filename_zoom=date("d-m-y")."_".date("h:i:s").".json";
	$p8path=put_file($target,$mode,"Zoom",$filename_zoom,$zoom_json);
	$sql15="INSERT INTO `medium_15_zoom`(`id`, `target`, `zoom_json`) VALUES (NULL,'$target','$zoom_json')";
	if (mysqli_query($conn, $sql15)) {
		echo "zoom record created successfully\n";
	} else {
		echo "Error: " . $sql15. "<br>" . mysqli_error($conn);
	}


	//16th tool
	$parsero_output = "Parsero \n".shell_exec("parsero -u '$target' -o");
	$parsero_result = removeasci(explode("\n",$parsero_output));
	foreach ($parsero_result as $key => $value) {
		if (startsWith($value,"h")) {
			continue;
		}
		else{
			unset($parsero_result[$key]);
		}
	}
	$parsero = array();
	foreach ($parsero_result as $value) {
		$array = explode(' ', $value);
		$array[1] = trim($array[1]);
		$array[0] = trim($array[0]);
		$parsero[$array[0]] = $array[1];
	}
	$parsero_json = json_encode($parsero);
	$filename_parsero=date("d-m-y")."_".date("h:i:s").".json";
	$p9path=put_file($target,$mode,"Parsero",$filename_parsero,$parsero_json);
	$sql16="INSERT INTO `medium_16_parsero`(`id`, `target`, `parsero_json`) VALUES (NULL,'$target','$parsero_json')";
	if (mysqli_query($conn, $sql16)) {
		echo "parsero record created successfully\n";
	} else {
		echo "Error: " . $sql16 . "<br>" . mysqli_error($conn);
	}
	


	//17th tool
	$mainpath_dnstwist=getcwd()."/module/dnstwist/dnstwist.py";
	$dnstwist_output = shell_exec("python3 '$mainpath_dnstwist' -r -f json '$target' ");
	$dnsttwist_json=$dnstwist_output;
	$filename_dnstwist=date("d-m-y")."_".date("h:i:s").".json";
	$path_dnstwist=put_file($target,"Medium","DNSTwist",$filename_dnstwist,$dnsttwist_json);
	$sql17="INSERT INTO `medium_17_dnstwist`(`id`, `target`, `dnstwist_path`) VALUES (NULL,'$target','$path_dnstwist')";
	if (mysqli_query($conn, $sql17)) {
		echo "dnstwist record created successfully\n";
	} else {
		echo "Error: " . $sql17 . "<br>" . mysqli_error($conn);
	}

	
	//18th tool
	$company="charusat";
	$crosslinked_path=getcwd()."/module/crosslinked/crosslinked.py";
	$crosslinked = shell_exec("python3 '$crosslinked_path' -f {first}.{last}@'$target' '$company'");
	$crosslinkedfile = fopen(getcwd()."/module/crosslinked/names.txt", "r") or die("Unable to open file!");
	$var1=fread($crosslinkedfile,filesize(getcwd()."/module/crosslinked/names.txt"));
	fclose($crosslinkedfile);
	$var1=explode("\n",$var1);
	$crossjson=json_encode($var1);
	unlink(getcwd()."/module/crosslinked/names.txt");
	$filename_crooslinked=date("d-m-y")."_".date("h:i:s").".json";
	$p10path=put_file($target,$mode,"Cross_Linked",$filename_crooslinked,$crossjson);
	$sql18="INSERT INTO `medium_18_crosslinked`(`id`, `target`, `cross_json`) VALUES (NULL,'$target','$crossjson')";
	if (mysqli_query($conn, $sql18)) {
		echo "crosslinked record created successfully\n";
	} else {
		echo "Error: " . $sql18. "<br>" . mysqli_error($conn);
	}


	//19th tool
	$filename1=$target."output.xml";
	$ssloutput = " \n".shell_exec("sslscan --show-cerificate --xml='$filename1' '$target'");
	$path=getcwd().$filename1;
	$xml=simplexml_load_file($path) or die("Error: Cannot create object");
	$josnssl=json_encode($xml);
	$filename_sslscan=date("d-m-y")."_".date("h:i:s").".json";
	$p11path=put_file($target,$mode,"SSLScan",$filename_sslscan,$josnssl);
	$sql19="INSERT INTO `medium_19_sslscan`(`id`, `target`, `sslscan_json`) VALUES (NULL,'$target','$josnssl')";
	if (mysqli_query($conn, $sql19)) {
		echo "sslscan record created successfully\n";
	} else {
		echo "Error: " . $sql19 . "<br>" . mysqli_error($conn);
	}


	//20th tool
	$lbd_path=getcwd()."/module/lbd/lbd";
	$lbd_output = trim(shell_exec("'$lbd_path' '$target'"));
	$lbd_result = removeasci(explode("\n",$lbd_output));
	$lbdout=array();
	for($i=0;$i<sizeof($lbd_result);$i++){
		$line=$lbd_result[$i];
    	if($line!=""){
			$ps=explode(":",$line);
			$lbdout[trim($ps[0])]=trim($ps[1]);
		}	
	}
	$lbd=json_encode($lbdout);
	$filename_lbd=date("d-m-y")."_".date("h:i:s").".json";
	$p12path=put_file($target,$mode,"LBD",$filename_lbd,$lbd);
	$sql20="INSERT INTO `medium_20_lbd`(`id`, `target`, `lbd_json`) VALUES (NULL,'$target','$lbd')";
	if (mysqli_query($conn, $sql20)) {
		echo "lbd record created successfully\n";
	} else {
		echo "Error: " . $sql20 . "<br>" . mysqli_error($conn);
	}
	
	break;
		
	default:

		# code...
		break;
}


?>
