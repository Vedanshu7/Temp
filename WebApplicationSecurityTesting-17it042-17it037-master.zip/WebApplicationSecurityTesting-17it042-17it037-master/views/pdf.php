<?php
require(getcwd().'/PDF Data/fpdf182/fpdf.php');
include('db.php');
session_start();
if(!isset($_SESSION['user_email_address'])){
   session_destroy();
   header("location:login.php");
}
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('logo.png',10,7,15);
    // Arial bold 15
    $this->SetFont('Arial','U',12);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'Pentesting Report','C');
    // Line break
    $this->Image('logo2.png',185,8  ,15);
    $this->Line(500, 25,0,25);
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    $this->Line(500, 280,0,280);
    // Page number
    $this->Cell(0,10,$this->PageNo(),0,0,'C');
}

function ChapterTitle($num, $label)
{
    // Arial 12
    $this->SetFont('Arial','B',12);
    // Background color
    $this->SetFillColor(200,220,255);
    // Title
    $this->Cell(0,7,"Chapter $num : $label",0,1,'L',true);
    // Line break
    $this->Ln(4);
}

function SubChapterTitle($num, $label)
{
    // Arial 12
    $this->SetFont('Arial','B',12);
    // Background color
    //$this->SetFillColor(200,220,255);
    // Title
    $this->Cell(0,6,"$num $label",0,1,'L');
    // Line break
    $this->Ln(4);
}

function ChapterBody($file)
{
    // Read text file
    $txt = file_get_contents($file);
    // Times 12
    $this->SetFont('Times','',12);
    // Output justified text
    $this->MultiCell(0,5,$txt);
    // Line break
    $this->Ln();
}

function SubPrintChapter($num, $title, $file)
{
    //$this->Ln(2);
    $this->SubChapterTitle($num,$title);
    $this->ChapterBody($file);
}

function PrintChapter($num, $title, $file)
{
    $this->AddPage();
    $this->ChapterTitle($num,$title);
    $this->ChapterBody($file);
}

}

// Instanciation of inherited class
$pdf = new PDF();

$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Image('main1.jpg',-100,-20,400);
$pdf->SetFont('Arial','B',16);
$pdf->Ln(200);
$pdf->Write(45,'Pentester:');
$pdf->LN(23);
$pdf->Write(23,'Target:');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Write(10,'Document Details');
$pdf->LN(23);
$pdf->SetFont('Arial','B',10);
$pdf->setFillColor(179, 204, 204);
$pdf->Cell(0,8,"Document Version Control",1,1,'L',True);
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,8,"Document Title",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Document ID",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Last Edit Date",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Version#",1,0);
$pdf->Cell(0,8,"",1,1,true);


$pdf->LN(23);
$pdf->SetFont('Arial','B',10);
$pdf->setFillColor(179, 204, 204);
$pdf->Cell(0,8,"Document Submission Details",1,1,'L',True);
$pdf->SetFont('Arial','',10);
$pdf->Cell(50,8,"Date",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Classification",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Submitted to",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Designation",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Contact No.",1,0);
$pdf->Cell(0,8,"",1,1,true);
$pdf->Cell(50,8,"Email",1,0);
$pdf->Cell(0,8,"",1,1,true);



$pdf->PrintChapter(1,'Introduction',getcwd().'/PDF Data/Chapter-1.txt');
$pdf->SubPrintChapter(1.1,'Puporse',getcwd().'/PDF Data/Chapter-1.1.txt');
$pdf->SubPrintChapter(1.2,'Pen Testing',getcwd().'/PDF Data/Chapter-1.2.txt');
$pdf->SubPrintChapter(1.3,'Vulnerability Assessment',getcwd().'/PDF Data/Chapter-1.3.txt');
$pdf->PrintChapter(2,'Methodology',getcwd().'/PDF Data/Chapter-2.txt');
$pdf->PrintChapter(3,'Tools Summary',getcwd().'/PDF Data/Chapter-3.txt');
$pdf->SetFont('Times','B',10);
$pdf->Cell(12,10,"SR No.",1,0,'C');
$pdf->Cell(80,10,"Tools Category",1,0,'C');
$pdf->Cell(53,10,"Tools Name",1,0,'C');
$pdf->Cell(45,5,"Severity",1,1,'C');
$pdf->Cell(145,5,"",0,0);
$pdf->Cell(15,5,"Easy",1,0,'C');
$pdf->Cell(15,5,"Medium",1,0,'C');
$pdf->Cell(15,5,"Hard",1,1,'C');


$select = "SELECT * FROM `tool`";
$result = mysqli_query($conn,$select);
while($row = $result->fetch_object()){
  $pdf->SetFont('Times','',10);
  $tool_id = $row->id;
  $tool_category = $row->tool_category;
  $tool_name = $row->tool_names;
  $level_Easy = $row->level_Easy;
  $level_medium = $row->level_medium;
  $level_hard = $row->level_hard;
  $pdf->Cell(12,8,$tool_id,1,0,'C');
  $pdf->Cell(80,8,$tool_category,1,0,'C');
  $pdf->Cell(53,8,$tool_name,1,0,'C');
  $pdf->Cell(15,8,$level_Easy,1,0,'C');
  $pdf->Cell(15,8,$level_medium,1,0,'C');
  $pdf->Cell(15,8,$level_hard,1,0,'C');
  $pdf->Ln();
}

$user=$_SESSION['user_email_address'];
$select1 = "SELECT * FROM `toolData` where id ='$user'";
$result1 = mysqli_query($conn,$select1);
$i=4;

while($row = mysqli_fetch_array($result1, MYSQLI_NUM)){
  
  $id = $row[0];
  $tool_name = $row[1];
  $file_Name = $row[2];

  $pdf->PrintChapter($i,$tool_name,$file_Name);
  $i+=1;  
 
}















$pdf->Output();
?>