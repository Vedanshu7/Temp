<?php
include 'db.php';
function removeasci($test){
$test=preg_replace('#\\x1b[[][^A-Za-z]*[A-Za-z]#', '', $test);
return $test;
}
function put_file($target,$mode,$tool,$filename,$data)
{
  
  while (true) {
  $mainpath = getcwd()."/Output";
  if(is_dir($mainpath)) {
    $mainpath.="/".$target;
    if(is_dir($mainpath)){
      $mainpath.="/".$mode;
      if(is_dir($mainpath)){
        $mainpath.="/".$tool;
        if(is_dir($mainpath)){
          $mainpath.="/".$filename;
          $myfile = fopen($mainpath, "w") or die("Unable to open file!");
          fwrite($myfile, $data);
          fclose($myfile);
          return $mainpath;
          break;
        }
        else{
          mkdir($mainpath);
        }
      }
      else{
        mkdir($mainpath);
      }
    }
    else{
      mkdir($mainpath);
    }
  } else {
    mkdir($mainpath);
  }
}
}
function remove_http($url) {
    $disallowed = array('http://', 'https://');
    foreach($disallowed as $d) {
       if(strpos($url, $d) === 0) {
          return str_replace($d, '', $url);
       }
    }
    return $url;
 }

$target=remove_http($_GET['target']);

$str = exec("ping -c 1 '$target'");
if ($result == 0){
  echo "ping succeeded";
}else{
  $mode="";
}

$rapidscan_path=getcwd()."/module/rapidscan.py";
$rapidscan_output = "RapidScan \n".shell_exec("python '$rapidscan_path' '$target' 2>&1");
$rapidscan_result = removeasci(explode("\n",$rapidscan_output));
$report_path=getcwd()."/module/Rapidscan/".$target."Report";
$fileContents = file_get_contents($report_path);
$filename_rapidscan=date("d-m-y")."_".date("h:i:s").".txt";
$path_rapidscan=put_file($target,"Expert","Rapidscan",$filename_rapidscan,$fileContents);

$sql1="INSERT INTO `expert_1_rapidscan`(`id`, `target`, `rapid_path`) VALUES (NULL,'$target','$path_rapidscan')";
if (mysqli_query($conn, $sql1)) {
   echo "Rapidscan record created successfully\n";
} else {
  echo "Error: " . $sql1. "<br>" . mysqli_error($conn);
}


?>