<?php
#ini_set('display_errors',0);
include("db.php");
function get_domain($url)
{
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : $pieces['path'];
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}

function replace($string){
$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\[\]\.\(\)%&-]/s', '', $string);
    return $string;
}

function replace3($string){
$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\]\.\(\)%&-]/s', '', $string);
    return $string;
}


function replace5($string){
$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\]\.\(\)%&-]/s', '', $string);
    return $string;
}


function replace1($string){
$string=preg_replace('/[^a-zA-Z0-9_ \/\/\:%\[\]\.\(\)%&]/s', '', $string);
    return $string;
}

function rawdata($result)
{
$out = array();
$other=array();
$ds=0;
$ns=0;
$ad=-1;
$n=0;
foreach ($result as $line){
if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }

if(substr_count($line,":") > 1){
 $loc=strpos($line,":");
          $ps = str_split($line,$loc+1);
         
          if(sizeof($ps)>2){
          for($i=2;$i<sizeof($ps);$i++){
          $ps[1].=$ps[$i];
          }
          }
          $temp=explode(":", $ps[0]);
          if($temp[0]=="Domain Status"){
          $temp[0]=$temp[0].$ds;
          $ds+=1;
          }
          if($temp[0]=="Name Server"){
          $temp[0]=$temp[0].$ns;
          $ns+=1;
          }
          if($temp[0]=="Address"){
          if($ad==-1){
          $ad+=1;
          }
          else{
          $temp[0]=$temp[0].$ad;
          $ad+=1;
          }
          }
          if($temp[0]=="Name"){
          $temp[0]=$temp[0].$n;
          $n+=1;
          }
          $out[trim($temp[0])] =trim(replace($ps[1]));
 
 
}
else if(substr_count($line,":") < 1){
$other.=$line.",";
}
else{
$ps = explode(':',$line);
//echo $ps;
if($ps[0]=="Domain Status"){
          $ps[0]=$ps[0].$ds;
          $ds+=1;
          }
          if($ps[0]=="Name Server"){
          $ps[0]=$ps[0].$ns;
          $ns+=1;
          }
          if($ps[0]=="Address"){
          if($ad==-1){
          $ad+=1;
          }
          else{
          $ps[0]=$ps[0].$ad;
          $ad+=1;
          }
          }
          if($ps[0]=="Name"){
          $ps[0]=$ps[0].$n;
          $n+=1;
          }
$out[trim($ps[0])] =trim(replace($ps[1]));
}
}
print_r("<pre>");
print_r($other);
print_r("<pre>");
return $out;
}
function srawdata($result)
{

$other="";
$out=array();
foreach ($result as $line){
if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }

if(substr_count($line,":") < 1){
$other.=$line.",";
}

}
preg_match_all('#[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $other, $match);
for($i=0;$i<sizeof($match[0]);$i++){
if(get_domain($match[0][$i])!=false){
array_push($out,$match[0][$i]);
}
}
return $out;
}
function removenikto($result){
$out = array();

foreach ($result as $line){
if (substr($line,0,1) == '%' || substr($line,0,1) == '#'){ continue; }
if(substr_count($line,"-")>=1){
$ind1=array_search(":",$line,true);
$ind2=array_search("-",$line,true);
if($ind1>$ind2){
$ps=explode("-",$line);
$out[$ps[0]]=$ps[1];
}
}

if(substr_count($line,":") > 1){
 $loc=strpos($line,":");
          $ps = str_split($line,$loc+1);
         
          if(sizeof($ps)>2){
          for($i=2;$i<sizeof($ps);$i++){
          $ps[1].=$ps[$i];
          }
          }
          $temp=explode(":", $ps[0]);
         
          $out[trim(replace1($temp[0]))] =trim(replace1($ps[1]));
 
 
}
else if(substr_count($line,":") < 1){

if(replace1($line)!="" && replace1($line)!=" " && replace1($line)!="Nikto v2.1.6" && replace1($line)!=" Nikto v2.1.6"){
$out["Other Info"].=replace1($line).",";
}

}
else{
$ps = explode(':',$line);
//echo $ps;

$out[trim(replace1($ps[0]))] =trim(replace1($ps[1]));
}
}

return $out;
}

function filtersitadel($result){
foreach ($result as $line){
if(substr($line, 1, 2) === '+')
{
echo $line;
}
}
}
function replace2($string){
$string=preg_replace('/[^a-zA-Z0-9_\/\/\:%\[\]\.\(\)%&\|]/s', '', $string);
    return $string;
}

function replace4($string){
$string=preg_replace('/[^a-zA-Z0-9_\/\/\:%\.\(\)%&\|]/s', ' ', $string);
    return $string;
}



function removeasci($test){
$test=preg_replace('#\\x1b[[][^A-Za-z]*[A-Za-z]#', '', $test);
return $test;
}
function startsWith ($string, $startString)
{
    $len = strlen($startString);
    return (substr($string, 0, $len) === $startString);
}

function clean($result){
  foreach ($result as $key => $value) {
  if($value==""){
    unset($result[$key]);
  }
}
return $result;
}
function put_file($target,$mode,$tool,$filename,$data)
{
  
  while (true) {
  $mainpath = getcwd()."/Output";
  if(is_dir($mainpath)) {
    $mainpath.="/".$target;
    if(is_dir($mainpath)){
      $mainpath.="/".$mode;
      if(is_dir($mainpath)){
        $mainpath.="/".$tool;
        if(is_dir($mainpath)){
          $mainpath.="/".$filename;
          $myfile = fopen($mainpath, "w") or die("Unable to open file!");
          fwrite($myfile, $data);
          fclose($myfile);
          return $mainpath;
          break;
        }
        else{
          mkdir($mainpath);
        }
      }
      else{
        mkdir($mainpath);
      }
    }
    else{
      mkdir($mainpath);
    }
  } else {
    mkdir($mainpath);
  }
}
}
function remove_http($url) {
  $disallowed = array('http://', 'https://');
  foreach($disallowed as $d) {
     if(strpos($url, $d) === 0) {
        return str_replace($d, '', $url);
     }
  }
  return $url;
}

$target=remove_http($_GET['target']);
$str = exec("ping -c 1 '$target'");
if ($result == 0){
  echo "ping succeeded";
}else{
  $mode="";
}
$mode="Hard";



switch ($mode) {
case 'Hard':

//1st tool
$honeycaught_output=shell_exec("nmap '$target' -p 5000 2>&1");
$honeycaught_output.=shell_exec("nmap '$target' -p 21 2>&1");
$honeycaught_output.=shell_exec("nmap '$target' -p 23 2>&1");
$honeycaught_output.=shell_exec("nmap '$target' -p 53 2>&1");
$honeycaught_result=explode("\n", $honeycaught_output);
$filename_honeycaught=date("d-m-y")."_".date("h:i:s").".txt";
$path_honeycaught=put_file($target,$mode,"Nmap-HoneyCaught",$filename_honeycaught,$honeycaught_output);

$sql1="INSERT INTO `hard_1_honeycaught`(`id`, `target`, `honeypot_path`) VALUES (NULL,'$target','$path_honeycaught')";
if (mysqli_query($conn, $sql1)) {
   echo "Nmap-HoneyCaught record created successfully\n";
} else {
  echo "Error: " . $sql1. "<br>" . mysqli_error($conn);
}





//2nd tool
$path_blackwidow=getcwd()."/module/BlackWidow/blackwidow.py";
$blackwidow_output = "Blackwidow \n".shell_exec("python '$path_blackwidow' -u https://'$target'");

$blackwidow_result = removeasci(explode("\n",$blackwidow_output));

$blackwidow_out=array();
$comman_path=getcwd()."/module/BlackWidow/";
foreach ($blackwidow_result as $line) {
  if(startsWith($line,$comman_path)){
    array_push($blackwidow_out,$line);
  }
}
$link=array_pop($blackwidow_out);

//echo $link;
$BlackWidow_folder=str_replace($comman_path,"", $link);
$BlackWidow_folder=str_replace("/","",$BlackWidow_folder);
//echo $BlackWidow_folder;
$timestamp=date("d-m-y")."_".date("h:i:s");
$find=shell_exec("find '$link' -name \*.txt -printf '%f\n'");
$find_result=explode("\n",$find);
$path_array=array();
foreach ($find_result as $line) {
  if($line!=""){
    $new_path=$link.$line;
    $myfile = fopen($new_path, "r") or die("Unable to open file!");
    if(filesize($new_path) >0){
      $blackwidow_file=str_replace($BlackWidow_folder,"",$line);
      $blackwidow_file=str_replace("-","",$blackwidow_file);
      $filename_blackwidow=$timestamp."_".$blackwidow_file;
      $blackwidow_json=json_encode(fread($myfile,filesize($new_path)));
      fclose($myfile);
      $black_file=put_file($target,"Hard","Blackwidow",$filename_blackwidow,$blackwidow_json);
      array_push($path_array,$black_file);    
    }
    else{
    fclose($myfile);
  }
  }
}
$path_json=json_encode($path_array);
$sql2="INSERT INTO `hard_2_blackwidow`(`id`, `target`, `blackwidow_path`) VALUES (NULL,'$target','$path_json')";
if (mysqli_query($conn, $sql2)) {
   echo "blackwidow record created successfully\n";
} else {
  echo "Error: " . $sql2. "<br>" . mysqli_error($conn);
}

//3rd tool
$webscanner_path=getcwd()."/module/WebScanner/main.pl";
$webscanner_output = "Web Scanner \n".shell_exec("perl '$webscanner_path' '$target'");
$webscanner_result = replace5(removeasci(explode("\n",$webscanner_output)));
foreach ($webscanner_result as $key => $value) {
if(strpos($value, ":") !== false){
  continue;
}
else{
  unset($webscanner_result[$key]);
}
}

$WebScanner = array();
foreach ($webscanner_result as $value) {
    $array = explode(': ', $value);
    $array[1] = trim($array[1]);
    $array[0] = trim($array[0]);
    $WebScanner[$array[0]] = $array[1];
}

$webscanner_json = json_encode($WebScanner);



$filename_webscanner=date("d-m-y")."_".date("h:i:s").".json";
$path_webscanner=put_file($target,"Hard","Web_Scanner",$filename_webscanner,$webscanner_json);
$sql3="INSERT INTO `hard_3_webscanner`(`id`, `target`, `webscanner_json`) VALUES (NULL,'$target','$webscanner_json')";
if (mysqli_query($conn, $sql3)) {
  echo "webscanner record created successfully\n";
} else {
  echo "Error: " . $sql3 . "<br>" . mysqli_error($conn);
}




//4th tool
$sitebroker_path=getcwd()."/module/SiteBroker/SiteBroker.py";
$siteBroker_output = shell_exec("python3 '$sitebroker_path' '$target'");
$sitebroker_result = replace4(removeasci(explode("\n",$siteBroker_output)));
$col=array("CloudflareBypassOf","ReverseIPOF","NameserversOf","BannerOf");
//unset($dirhunt_result[0]);
$sitebroker_result=clean($sitebroker_result);
$CloudflareBypass=array();
$ReverseIP=array();
$Nameservers=array();
$Banner=array();
$mainarray=array(&$CloudflareBypass,&$ReverseIP,&$Nameservers,&$Banner);
$c=0;
foreach ($sitebroker_result as $key => $value) {
  if(in_array($value,$col)){
    for($i=$key+1;$i<sizeof($sitebroker_result);$i++){
      if(in_array($sitebroker_result[$i],$col)){
        $c+=1;
        break;
      }
      else{
        $arr=&$mainarray[$c];
        array_push($arr, $sitebroker_result[$i]);
        
      }
    }
  }
}
$CloudflareBypass=clean($CloudflareBypass);
$ReverseIP=clean($ReverseIP);
$Nameservers=clean($Nameservers);
$Banner=clean($Banner);
$CloudflareBypass_json=json_encode($CloudflareBypass);
$ReverseIP_json=json_encode($ReverseIP);
$Nameservers_json=json_encode($Nameservers);
$Banner_json=json_encode($Banner);
$timestamp=date("d-m-y")."_".date("h:i:s");
$filename_sitebroker=$timestamp.$col[0].".json";
$file=put_file($target,"Hard","SiteBroker",$filename_sitebroker,$CloudflareBypass_json);
$filename_sitebroker=$timestamp.$col[1].".json";
$file=put_file($target,"Hard","SiteBroker",$filename_sitebroker,$ReverseIP_json);
$filename_sitebroker=$timestamp.$col[2].".json";
$file=put_file($target,"Hard","SiteBroker",$filename_sitebroker,$Nameservers_json);
$filename_sitebroker=$timestamp.$col[3].".json";
$file=put_file($target,"Hard","SiteBroker",$filename_sitebroker,$Banner_json);
$sql4="INSERT INTO `hard_4_sitebroker`(`id`, `target`, `cloudflarebypass_json`, `reverseip_json`, `nameservers_json`, `banner_json`) VALUES (NULL,'$target','$CloudflareBypass_json','$ReverseIP_json','$Nameservers_json','$Banner_json')";
if (mysqli_query($conn, $sql4)) {
   echo "sitebroker record created successfully\n";
} else {
  echo "Error: " . $sql4. "<br>" . mysqli_error($conn);
}

//5th tool
$sslyze_output = "SSLyze\n".shell_exec("sslyze --regular '$target' --json_out=- ");
    $issl=json_encode($sslyze_output);
    $filename_sslyze=date("d-m-y")."_".date("h:i:s").".json";
    $path_sslyze=put_file($target,"Hard","SSLyze",$filename_sslyze,$issl);
    $sql5="INSERT INTO `hard_5_sslyze`(`id`, `target`, `ssl_path`) VALUES (NULL,'$target','$path_sslyze')";
    if (mysqli_query($conn, $sql5)) {
      echo "SSLyze record created successfully\n";
    } else {
      echo "Error: " . $sql5 . "<br>" . mysqli_error($conn);
    }


//6th tool
$password_path=getcwd()."/Data/passwords.txt";
$WpScanoutput .= "7. Wpscan \n".shell_exec("wpscan --url https://charusat.ac.in -e -P '$password_path' -U -t 100");
$WpScanresult2 = explode("[+]",$WpScanoutput,100);
$out5 = replace2(removeasci($WpScanresult2));
unset($out5[0]);
unset($out5[2]);
$jsondata7=json_encode($out5);
$filename_wpscan=date("d-m-y")."_".date("h:i:s").".json";
$path_wpscan=put_file($target,$mode,"Wpscan",$filename_wpscan,$jsondata7);

$sql6="INSERT INTO `hard_6_wpscan`(`id`, `target`, `wp_path`) VALUES (NULL,'$target','$path_wpscan')";

if (mysqli_query($conn, $sql6)) {
  echo "Wpscan record created successfully\n";
} else {
  echo "Error: " . $sql6 . "<br>" . mysqli_error($conn);
}


//7th tool
$cgi_path=getcwd()."/module/Pegasus-cgi/cgi.pl";

$cgi_output=shell_exec("perl '$cgi_path' '$target'");

$cgi_result=explode("\n", $cgi_output);
$cgi_out=array();
foreach ($result as $line) {
  if(startsWith($line,"Searching for")){
    $line=str_replace("Searching for","",$line);
    $ps=explode(":",$line);
    $cgi_out[trim($ps[0])]=trim($ps[1]);
  }
}

$cgi_json=json_encode($cgi_out);
$filename_cgi=date("d-m-y")."_".date("h:i:s").".json";
$path_cgi=put_file($target,$mode,"Pegasus-cgi",$filename_cgi,$cgi_json);
$sql7="INSERT INTO `hard_7_pegasus_cgi`(`id`, `target`, `cgi_json`) VALUES (NULL,'$target','$cgi_json')";
if (mysqli_query($conn, $sql7)) {
   echo "Pegasus record created successfully\n";
} else {
  echo "Error: " . $sql7. "<br>" . mysqli_error($conn);
}

//8th tool
$detective_output = "Detective \n".shell_exec("detective -d https://github.com -siv 2>&1");
$detective_result = replace4(removeasci(explode("\n",$detective_output)));

foreach ($detective_result as $key => $value) {
  if (strpos($value, "SUCCESS") !== false) {
    //trim($detective_result[$key]);
    continue;
  }
  else{
    unset($detective_result[$key]);
  }
  # code...
}
if(empty($detective_result)){
  $detective_result= array_fill("no endpoints found");
}


$detective_json=json_encode($detective_result);
$filename_detective=date("d-m-y")."_".date("h:i:s").".json";
$p16path=put_file($target,"Hard","Detective",$filename_detective,$detective_json);
$sql8="INSERT INTO `hard_8_detective`(`id`, `target`, `detective_json`) VALUES (NULL,'$target','$detective_json')";
if (mysqli_query($conn, $sql8)) {
   echo "detective record created successfully\n";
} else {
  echo "Error: " . $sql8. "<br>" . mysqli_error($conn);
}

//9th tool
$path="";
  $whatwaf_path=getcwd()."/module/WhatWaf/whatwaf.py";
  $whatwaf=shell_exec("python3 '$whatwaf_path' -u https://'$target' -F -J 2>&1");
  $whatwaf_result=explode("\n",$whatwaf);
  foreach ($whatwaf_result as $line) {
    if(startsWith($line,"[INFO]data has been written to file: ")){
      $ps=explode("[INFO]data has been written to file: ",$line);
      $path=$ps[1];
    }
  }
  $whatwaf_json;
  if($path!=""){
    $path=substr($path,1);
    $path=substr($path,0,-1);
    $f=fopen($path, "r");
    $json_file=fread($f,filesize($path));
    fclose($f);
    $whatwaf_json=json_encode($json_file);
  }
  else{
    $temp_json=array("apparent working tampers"=>null,"identified firewall"=>null,"is protected"=>true,"url"=>$target);
    $whatwaf_json=json_encode($temp_json);
  }
  $filename_whatwaf=date("d-m-y")."_".date("h:i:s").".json";
  $p4path=put_file($target,$mode,"WhatWaf",$filename_whatwaf,$whatwaf_json);
  $sql9="INSERT INTO `hard_9_whatwaf`(`id`, `target`, `whatwaf_json`) VALUES (NULL,'$target','$whatwaf_json')";
  if (mysqli_query($conn, $sql9)) {
    echo "whatwaf record created successfully\n";
  } else {
    echo "Error: " . $sql9 . "<br>" . mysqli_error($conn);
  }

//10th tool
$xshell_path=getcwd()."/module/XShell/SiteBroker.py";
$XShell_output = shell_exec("python3 '$xshell_path' '$target' 2>&1");
print_r($XShell_output);
$Xshell_result = replace4(removeasci(explode("\n",$XShell_output)));
$Xshell_result=clean($Xshell_result);
if(empty($Xshell_result)){
  $Xshell_result=array("Shell"=>"Not Found");
  $xshell_json=json_encode($Xshell_result);
}
else{
  $xshell_json=json_encode($Xshell_result);
}

$filename_xshell=date("d-m-y")."_".date("h:i:s").".json";
$file=put_file($target,"Hard","XShell",$filename_xshell,$xshell_json);
$sql10="INSERT INTO `hard_10_xshell`(`id`, `target`, `xshell_json`) VALUES (NULL,'$target','$xshell_json')";

if (mysqli_query($conn, $sql10)) {
   echo "xshell record created successfully\n";
} else {
  echo "Error: " . $sql10. "<br>" . mysqli_error($conn);
}
 


break;

default:

break;
}


?>


